PrintDemo1.dpr
--------------

- Needs Delphi 2 or higher.
- Demonstrates printing with the TSynPrintout component from the
  SynEditPrint_Old.pas unit.  This is not registered on the component palette,
  it is created at runtime.


